---
title: API Reference

language_tabs: # must be one of https://git.io/vQNgJ
  - python
  - php
  - java
  - csharp

toc_footers:
  - <a href='https://wiki.aichotels.net.cn/en/'> English </a>
  - <a href='https://wiki.aichotels.net.cn/cn/'> 中文 </a>
  - <a href='https://www.aichotels.com'>Click here to  visit AIC hotels website</a>
  - <a href='https://github.com/lord/slate'>Documentation Powered by Slate</a>



search: true
---

# Language Selection 语言选择

- [中文文档](https://wiki.aichotels.net.cn/cn/)
- [English document](https://wiki.aichotels.net.cn/en/)


